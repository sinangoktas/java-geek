package com.trimble.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

//Identify any errors in program(if any) and print the output

/**
 * Is it possible for HashMap here to have custom key? 
 *
 */
public class Collections {
//	public static void main(String[] args) {
//		// Block 1
//		Queue<String> queue = new LinkedList<>();
//		queue.add("Java");
//		queue.add("Android");
//		queue.add("Swift");
//		queue.add("XCode");
//		
//		System.out.println("Queue: \n  queue.remove() = " +  queue.remove() 
//		+ " queue.element() = "+ queue.element()
//		+ " queue.remove() = " + queue.remove()
//		+ " queue.peek() = "+ queue.peek()
//		+ " queue.remove() = " + queue.remove()
//		+ " queue.poll() = " + queue.poll()
//		+ " queue.poll() = " + queue.poll()
//		+ " queue.remove() = " + queue.remove());
//		
//		// Block 2
//		HashMap<String, String> hashMap = new HashMap<>();
//		Hashtable<String, String> hashTable = new Hashtable<>();
//		
//		hashMap.put("KEY1", "Value1");
//		hashMap.put(null, "Value2");
//		hashMap.put(null, "Value3");
//		hashMap.put("KEY4", null);
//		System.out.println("Values of HashMap: \n KEY1 = " + hashMap.get("KEY1") 
//		+ " KEY2 = " + hashMap.get(null) 
//		+ " KEY3 = " + hashMap.get(null) 
//		+ " KEY4 = " + hashMap.get("KEY4"));
//		
//		hashTable.put("KEY1", "Value1");
//		hashTable.put(null, "Value2");
//		hashTable.put(null, "Value3");
//		hashTable.put("KEY4", null);
//		System.out.println("Values of HashTable: \n KEY1 = " + hashTable.get("KEY1") 
//		+ " KEY2 = " + hashTable.get(null) 
//		+ " KEY3 = " + hashTable.get(null) 
//		+ " KEY4 = " + hashTable.get("KEY4"));
//		
//		// Block 3
//		List<Integer> list = new ArrayList<>();
//		Set<Integer> set = new HashSet<>();
//		list.add(1);
//		list.add(3);
//		list.add(5);
//		
//		set.add(1);
//		set.add(2);
//		set.add(3);
//		set.add(4);
//		set.add(4);
//		
//		set.addAll(list);
//		System.out.println("Set:" + set);
//		Set<Integer> set2 = new HashSet<>();
//		set2.add(2);
//		set2.add(4);
//		set.retainAll(set2);
//		System.out.println("Set:" + set);
//		
//	}
}